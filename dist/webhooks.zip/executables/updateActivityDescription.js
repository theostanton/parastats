"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.formatAggregationResult = formatAggregationResult;
exports.updateActivityDescription = updateActivityDescription;
exports.generateStats = generateStats;
exports.getAllTimeWingAggregationResult = getAllTimeWingAggregationResult;
exports.getAllTimeAggregationResult = getAllTimeAggregationResult;
exports.getSameYearAggregationResult = getSameYearAggregationResult;
const client_1 = require("../model/database/client");
const activities_1 = require("../model/database/activities");
const model_1 = require("../model/model");
function formatAggregationResult(result) {
    return `${elapsedTime(result.total_duration_sec)} over ${result.count} ${result.count == 1 ? "flight" : "flights"}`;
}
function elapsedTime(duration_secs) {
    if (duration_secs >= 60 * 60) {
        const hours = Math.floor(duration_secs / (60 * 60));
        const minutes = Math.floor((duration_secs - hours * 60 * 60) / 60);
        return `${hours}h ${minutes}min`;
    }
    const hours = Math.floor(duration_secs / (60 * 60));
    const minutes = (duration_secs - 60 * 60 * hours) / 60;
    return `${minutes}min`;
}
async function updateActivityDescription(activityId, dry = true) {
    // Get ActivityRow
    const result = await activities_1.activities.get(activityId);
    if (!result.success) {
        return (0, model_1.failed)(`No results for activityId=${activityId}`);
    }
    const activityRow = result.value;
    // Generate stats
    const stats = await generateStats(activityRow);
    // Check description is already winged
    const alreadyWinged = activityRow.description.includes("🌐 parastats.info");
    // If winged, replace stats
    let wingedDescription;
    if (alreadyWinged) {
        wingedDescription = activityRow.description.replace(/🪂[\s\S]*parastats.info/, stats);
    }
    else {
        wingedDescription = activityRow.description.replace(`🪂 ${activityRow.wing}`, stats);
    }
    console.log('wingedDescription');
    console.log(wingedDescription);
    console.log();
    // Update Strava Activity description
    //TODO
    // if success store updated else store failed
    return (0, model_1.success)(wingedDescription);
}
async function generateStats(activityRow) {
    const allTimeWing = await getAllTimeWingAggregationResult(activityRow);
    const allTime = await getAllTimeAggregationResult(activityRow);
    const sameYear = await getSameYearAggregationResult(activityRow);
    return `🪂 ${activityRow.wing}
This wing ${formatAggregationResult(allTimeWing)}
This year ${formatAggregationResult(sameYear)}
All time ${formatAggregationResult(allTime)}
🌐 parastats.info`;
}
async function getAllTimeWingAggregationResult(activityRow) {
    const client = await (0, client_1.getDatabase)();
    const result = await client.query(`
        select count(1)::int               as count,
               sum(duration_sec)::float    as total_duration_sec,
               sum(distance_meters)::float as total_distance_meters
        from activities
        where user_id = $1
          and wing = $2
          and start_date <= $3
    `, [activityRow.user_id, activityRow.wing, activityRow.start_date]);
    return result.rows[0].reify();
}
async function getAllTimeAggregationResult(activityRow) {
    const client = await (0, client_1.getDatabase)();
    const result = await client.query(`
        select count(1)::int               as count,
               sum(duration_sec)::float    as total_duration_sec,
               sum(distance_meters)::float as total_distance_meters
        from activities
        where user_id = $1
          and start_date <= $2
    `, [activityRow.user_id, activityRow.start_date]);
    return result.rows[0].reify();
}
async function getSameYearAggregationResult(activityRow) {
    const client = await (0, client_1.getDatabase)();
    const result = await client.query(`
        select count(1)::int               as count,
               sum(duration_sec)::float    as total_duration_sec,
               sum(distance_meters)::float as total_distance_meters
        from activities
        where user_id = $1
          and start_date <= $2
          and date_part('year', start_date) = date_part('year', $2)
    `, [activityRow.user_id, activityRow.start_date]);
    return result.rows[0].reify();
}
