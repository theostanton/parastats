"use strict";
// type Response = {
//     status: 200;
//     executable: string;
//     message: string;
//     error: string | undefined;
// }
