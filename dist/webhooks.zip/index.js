"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.webhookHandler = void 0;
const webhookHandler = (req, res) => {
    console.log("Received webhook:", req.body);
    if (req.query['hub.mode'] == 'subscribe') {
        res.status(200).send({ 'hub.challenge': req.query['hub.challenge'] });
    }
    else {
        res.status(200).send({ status: "OK2" });
    }
};
exports.webhookHandler = webhookHandler;
